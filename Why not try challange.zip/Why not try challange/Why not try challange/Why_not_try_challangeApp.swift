//
//  Why_not_try_challangeApp.swift
//  Why not try challange
//
//  Created by Link, Ty - Student on 10/1/24.
//

import SwiftUI

@main
struct Why_not_try_challangeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
